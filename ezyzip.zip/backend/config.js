export const PORT = 5555;

export const mongoDBURL =
  "mongodb+srv://himanshu0614:BookStore250310@cluster0.ui0ecox.mongodb.net/?retryWrites=true&w=majority";
